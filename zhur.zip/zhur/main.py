import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QPushButton, QVBoxLayout,
    QWidget, QTableWidget, QTableWidgetItem, QMessageBox,
    QDialog, QFormLayout, QLineEdit, QDialogButtonBox
)
from PyQt5.QtCore import QTimer
import sqlite3

class RoadRepairApp(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Система управления бригадой по ремонту дорог")
        self.setGeometry(100, 100, 800, 600)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout(self.central_widget)

        self.label = QLabel("Система управления бригадой по ремонту дорог")
        self.layout.addWidget(self.label)

        self.buttons = {
            "Показать общую стоимость работы бригады": self.show_costs,
            "Показать незавершенные работы": self.show_unfinished_work,
            "Показать рейтинг техники": self.show_technical_rating,
            "Добавить запись в бригаду": self.add_to_brigade,
            "Добавить запись в технический парк": self.add_to_technical_park,
            "Добавить работу": self.add_work,
            "Удалить запись": self.confirm_delete,
            "Показать бригады": self.show_brigades,
            "Показать технический парк": self.show_technical_park
        }

        for text, func in self.buttons.items():
            button = QPushButton(text)
            button.clicked.connect(func)
            self.layout.addWidget(button)

        self.table_widget = QTableWidget()
        self.layout.addWidget(self.table_widget)
        self.table_widget.setObjectName('work_table')

        self.create_tables()
        self.load_data()

        # Create a QTimer object for periodic refresh
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(30000)

    def refresh_data(self):
        self.load_data()

    def create_tables(self):
        connection = sqlite3.connect("road_repair.db")
        cursor = connection.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Brigade (
                brigade_id INTEGER PRIMARY KEY,
                brigade_name TEXT NOT NULL
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS TechnicalPark (
                park_id INTEGER PRIMARY KEY,
                park_name TEXT NOT NULL,
                vehicle_type TEXT NOT NULL,
                brigade_id INTEGER,
                FOREIGN KEY (brigade_id) REFERENCES Brigade(brigade_id)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Work (
                work_id INTEGER PRIMARY KEY,
                work_location TEXT NOT NULL,
                work_volume REAL NOT NULL,
                work_cost REAL NOT NULL,
                start_date TEXT NOT NULL,
                end_date TEXT,
                brigade_id INTEGER,
                FOREIGN KEY (brigade_id) REFERENCES Brigade(brigade_id)
            )
        ''')

        connection.commit()
        connection.close()

    def load_data(self):
        connection = sqlite3.connect("road_repair.db")
        cursor = connection.cursor()

        cursor.execute('''
            SELECT brigade_name, SUM(work_cost) AS total_cost
            FROM Work
            JOIN Brigade ON Work.brigade_id = Brigade.brigade_id
            GROUP BY brigade_name
        ''')
        data = cursor.fetchall()

        self.table_widget.setRowCount(len(data))
        self.table_widget.setColumnCount(2)
        self.table_widget.setHorizontalHeaderLabels(["Название бригады", "Общая стоимость работы"])

        for row_index, row_data in enumerate(data):
            for col_index, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.table_widget.setItem(row_index, col_index, item)

        connection.close()

    def show_costs(self):
        self.load_data()

    def show_unfinished_work(self):
        connection = sqlite3.connect("road_repair.db")
        cursor = connection.cursor()

        cursor.execute('''
            SELECT work_location, start_date, end_date
            FROM Work
            WHERE end_date IS NULL OR end_date > DATE('now')
        ''')
        data = cursor.fetchall()

        self.table_widget.setRowCount(len(data))
        self.table_widget.setColumnCount(3)
        self.table_widget.setHorizontalHeaderLabels(["Место работы", "Дата начала", "Дата окончания"])

        for row_index, row_data in enumerate(data):
            for col_index, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.table_widget.setItem(row_index, col_index, item)

        connection.close()

    def show_technical_rating(self):
        connection = sqlite3.connect("road_repair.db")
        cursor = connection.cursor()

        cursor.execute('''
            SELECT vehicle_type, COUNT(*) AS count
            FROM TechnicalPark
            GROUP BY vehicle_type
            ORDER BY count DESC
        ''')
        data = cursor.fetchall()

        self.table_widget.setRowCount(len(data))
        self.table_widget.setColumnCount(2)
        self.table_widget.setHorizontalHeaderLabels(["Тип техники", "Количество"])

        for row_index, row_data in enumerate(data):
            for col_index, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.table_widget.setItem(row_index, col_index, item)

        connection.close()

    def show_brigades(self):  # Новый метод для отображения бригад
        connection = sqlite3.connect("road_repair.db")
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM Brigade')
        data = cursor.fetchall()

        self.table_widget.setRowCount(len(data))
        self.table_widget.setColumnCount(len(data[0]))
        self.table_widget.setHorizontalHeaderLabels([description[0] for description in cursor.description])

        for row_index, row_data in enumerate(data):
            for col_index, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.table_widget.setItem(row_index, col_index, item)

        connection.close()

    def show_technical_park(self):  # Новый метод для отображения технического парка
        connection = sqlite3.connect("road_repair.db")
        cursor = connection.cursor()

        cursor.execute('SELECT * FROM TechnicalPark')
        data = cursor.fetchall()

        self.table_widget.setRowCount(len(data))
        self.table_widget.setColumnCount(len(data[0]))
        self.table_widget.setHorizontalHeaderLabels([description[0] for description in cursor.description])

        for row_index, row_data in enumerate(data):
            for col_index, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.table_widget.setItem(row_index, col_index, item)

        connection.close()

    def get_table_name(self):
        tab_name = self.table_widget.objectName()
        if tab_name == 'work_table':
            return 'Work'
        elif tab_name == 'brigade_table':
            return 'Brigade'
        elif tab_name == 'technical_park_table':
            return 'TechnicalPark'

    def add_to_brigade(self):
        dialog = AddRecordDialog("Добавить запись в бригаду", ["Название бригады"])
        if dialog.exec_():
            brigade_name = dialog.get_data()[0]
            connection = sqlite3.connect("road_repair.db")
            cursor = connection.cursor()
            cursor.execute("INSERT INTO Brigade (brigade_name) VALUES (?)", (brigade_name,))
            connection.commit()
            connection.close()
            self.load_data()

    def add_to_technical_park(self):
        dialog = AddRecordDialog("Добавить запись в технический парк", ["Название парка", "Тип техники", "ID бригады"])
        if dialog.exec_():
            park_name, vehicle_type, brigade_id = dialog.get_data()
            connection = sqlite3.connect("road_repair.db")
            cursor = connection.cursor()
            cursor.execute("INSERT INTO TechnicalPark (park_name, vehicle_type, brigade_id) VALUES (?, ?, ?)", (park_name, vehicle_type, brigade_id))
            connection.commit()
            connection.close()
            self.load_data()

    def add_work(self):
        dialog = AddRecordDialog("Добавить работу", ["Место работы", "Объем работы", "Стоимость работы", "Дата начала", "Дата окончания", "ID бригады"])
        if dialog.exec_():
            work_location, work_volume, work_cost, start_date, end_date, brigade_id = dialog.get_data()
            connection = sqlite3.connect("road_repair.db")
            cursor = connection.cursor()
            cursor.execute("INSERT INTO Work (work_location, work_volume, work_cost, start_date, end_date, brigade_id) VALUES (?, ?, ?, ?, ?, ?)", (work_location, work_volume, work_cost, start_date, end_date, brigade_id))
            connection.commit()
            connection.close()
            self.load_data()

    def confirm_delete(self):
        selected_row = self.table_widget.currentRow()
        if selected_row != -1:
            reply = QMessageBox.question(self, 'Подтверждение удаления',
                                         'Вы уверены, что хотите удалить выбранную запись?',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                item_id = int(self.table_widget.item(selected_row, 0).text())
                table_name = self.get_table_name()
                connection = sqlite3.connect("road_repair.db")
                cursor = connection.cursor()
                cursor.execute(f"DELETE FROM {table_name} WHERE {table_name}_id=?", (item_id,))
                connection.commit()
                connection.close()
                self.load_data()
        else:
            QMessageBox.warning(self, 'Ошибка', 'Выберите запись для удаления!', QMessageBox.Ok)


class AddRecordDialog(QDialog):
    def __init__(self, title, labels):
        super().__init__()

        self.setWindowTitle(title)
        self.layout = QVBoxLayout()
        self.form_layout = QFormLayout()

        self.line_edits = [QLineEdit() for _ in labels]
        for label, line_edit in zip(labels, self.line_edits):
            self.form_layout.addRow(label, line_edit)

        self.layout.addLayout(self.form_layout)

        self.buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel,
            self
        )
        self.layout.addWidget(self.buttons)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)

        self.setLayout(self.layout)

    def get_data(self):
        return [line_edit.text() for line_edit in self.line_edits]


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RoadRepairApp()
    window.show()
    sys.exit(app.exec_())
